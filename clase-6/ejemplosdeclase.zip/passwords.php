<?php

echo md5('password123456');
echo '<br/>';
echo sha1('password123456');
echo '<br/>';
echo password_hash('password123456', PASSWORD_DEFAULT);
echo '<br/>';
echo password_hash('password123456', PASSWORD_BCRYPT);
echo '<br/>';
echo password_hash('password123456', PASSWORD_BCRYPT, ['salt' => 'M1Sup3rR4nd0mC0d1g0D3S3gur1d4d']);
echo '<br/>';