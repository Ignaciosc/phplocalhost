<?php

$usuario = [
	'nombre' => 'Dario',
	'apellido' => 'Govergun',
	'edad' => 29,
	'secciones' => [1, 2, 3],
	'direccion' => [
		'calle' => 'Av. Monroe',
		'numero' => 860,
		'barrio' => 'Belgrano'
	]
];

$json = json_encode($usuario);

var_dump($json);

$jsonOtraVezArray = json_decode($json, true);
var_dump($jsonOtraVezArray);
