<?php

$filename = 'usuarios.json';

if(!file_exists($filename))
{
	$f = fopen($filename, 'w+');
}
else
{
	$f = fopen($filename, 'r');
}

$contenido = fread($f, filesize($filename));
fclose($f);
$contenido2 = file_get_contents($filename);

echo nl2br($contenido);
echo nl2br($contenido2);

while (($line = fgets($f)) !== false)
{
    echo nl2br($line) . '<hr>';
}