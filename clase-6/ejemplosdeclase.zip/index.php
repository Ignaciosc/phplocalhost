<?php
require_once('html.php');
?>

<?php echo htmlOpen('Home'); ?>
	<?php echo pageHeader('Home'); ?>
		<div class="jumbotron">
			<h1>YO SOY EL INDEX!</h1>
		</div>
<?php echo pageFooter(); ?>
<?php echo htmlClose(); ?>