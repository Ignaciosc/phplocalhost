<?php

require_once('Repositories' . DIRECTORY_SEPARATOR . 'PeliculasMySqlRepository.php');

$peliculasRepo = new PeliculasMySqlRepository();

$peliculasRepo->testConnection();

echo '<br/><br/><br/>';

$peliculasRepo->generateErrors();