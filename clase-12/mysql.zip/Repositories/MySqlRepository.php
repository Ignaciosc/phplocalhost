<?php

abstract class MySqlRepository
{
	/**
	 * @var PDO
	 */
	protected $db;

	protected function connect()
	{
		$this->db = new PDO(
			'mysql:host=localhost;dbname=peliculas_clase_4;charset=utf8mb4',
			'root',
			''
		);
	}

	protected function connectWithParams()
	{
		$this->db = new PDO(
			'mysql:host=localhost;dbname=peliculas_clase_4;charset=utf8mb4',
			'root',
			'',
			[
				PDO::ATTR_EMULATE_PREPARES => false,
				PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
			]
		);
	}

	protected function connectWithAttributes()
	{
		$this->db = new PDO(
			'mysql:host=localhost;dbname=peliculas_clase_4;charset=utf8mb4',
			'root',
			''
		);

		$this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
	}
}