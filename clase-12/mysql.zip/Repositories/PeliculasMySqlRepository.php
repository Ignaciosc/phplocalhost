<?php

require_once('MySqlRepository.php');

class PeliculasMySqlRepository extends MySqlRepository
{
	public function testConnection()
	{
		$this->connect();
		foreach($this->db->query('SELECT * FROM pelicula') as $row)
		{
			var_dump($row);
		}

		//Esto no hace falta con PDO. La conexión se cierra cuando el script termina.
		//Pero como vamos a ejecutar varias cosas seguidas con diferentes generaciones de instancias, la destruímos a mano.
		$this->db = null;

		echo '<br/><br/><br/>';

		$this->connectWithParams();
		$stmt = $this->db->prepare('SELECT * FROM pelicula');
		$stmt->execute();
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))
		{
		    var_dump($row);
		}

		$this->db = null;

		echo '<br/><br/><br/>';

		$this->connectWithAttributes();
		$stmt = $this->db->prepare('SELECT * FROM pelicula');
		$stmt->execute();
		var_dump($stmt->fetchAll(PDO::FETCH_ASSOC));

		$this->db = null;

		$this->connectWithAttributes();
		$stmt = $this->db->prepare('INSERT INTO pelicula...');
		$stmt->execute();
	}

	public function generateErrors()
	{
		$this->connect();
		var_dump($this->db->query('SELECT * FROM sarlangaaaa'));

		//Esto no hace falta con PDO. La conexión se cierra cuando el script termina.
		//Pero como vamos a ejecutar varias cosas seguidas con diferentes generaciones de instancias, la destruímos a mano.
		$this->db = null;

		echo '<br/><br/><br/>';

		$this->connectWithParams();
		var_dump($this->db->query('SELECT * FROM sarlangaaaa'));
		$this->db = null;

		echo '<br/><br/><br/>';

		$this->connectWithAttributes();
		var_dump($this->db->query('SELECT * FROM sarlangaaaa'));
		$this->db = null;
	}
}