<?php

if(!isset($_POST['terminos']))
{
	header('location: index.php?error=terminos');
	exit;
}

header('location: felicitaciones.html');
exit;