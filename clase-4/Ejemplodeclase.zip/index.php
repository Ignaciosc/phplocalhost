<?php

$error = false;
if($_POST)
{
	if(!isset($_POST['terminos']))
	{
		$error = true;
	}
	else
	{
		header('location: felicitaciones.html');
		exit;
	}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title>Digital House PHP 101</title>

	<!-- Bootstrap -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<div class="container">
		<h1>Registración</h1>
		<?php if ($error) { ?>
			<div class="alert alert-danger alert-dismissible" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<strong>Error!</strong> Debes aceptar los términos y condiciones.
			</div>
		<?php } ?>
		<form class="container" method="post" action="">
			<div class="form-group">
				<label for="exampleInputEmail1">Nombre</label>
				<input type="text" name="nombre" value="<?php echo (isset($_POST['nombre']) ? $_POST['nombre'] : '') ?>" class="form-control" id="exampleInputEmail1" placeholder="Nombre">
			</div>
			<div class="form-group">
				<label for="exampleInputEmail1">Apellido</label>
				<input type="text" name="apellido" class="form-control" id="exampleInputEmail1" placeholder="Apellido">
			</div>
			<div class="form-group">
				<label for="exampleInputEmail1">Email</label>
				<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Email">
			</div>
			<div class="form-group">
				<label for="exampleInputPassword1">Password</label>
				<input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
			</div>
			<label>Secciones</label>
			<div class="checkbox">
				<label>
					<input type="checkbox" value="1" name="secciones[]"> Sociales
				</label>
			</div>
			<div class="checkbox">
				<label>
					<input type="checkbox" value="2" name="secciones[]"> Policiales
				</label>
			</div>
			<div class="checkbox">
				<label>
					<input type="checkbox" value="3" name="secciones[]"> Deportes
				</label>
			</div>
			<div class="checkbox">
				<label>
					<input type="checkbox" value="4" name="secciones[]"> Ciudad
				</label>
			</div>
			<label>Fecha de Nacimiento</label>
			<div class="form-group">
				<select name="dia">
					<option value="">Día</option>
					<?php for ($i = 1; $i <= 31; $i++): ?>
						<option value="<?php echo $i; ?>"><?php echo $i; ?></option>
					<?php endfor; ?>
				</select>
				<select name="mes">
					<option value="">Mes</option>
					<?php for ($i = 1; $i <= 12; $i++)
					{ ?>
						<option value="<?php echo $i; ?>"><?php echo $i; ?></option>
					<?php } ?>
				</select>
				<select name="anio">
					<option value="">Año</option>
					<?php for ($i = date('Y'); $i >= 1900; $i--): ?>
						<option value="<?php echo $i; ?>"><?php echo $i; ?></option>
					<?php endfor; ?>
				</select>
			</div>
			<label>Descripción</label>
			<div class="form-group">
				<textarea cols="50" rows="10" name="description"></textarea>
			</div>
			<div class="checkbox">
				<label>
					<input type="checkbox" name="terminos" value="1"> Acepto los Términos y condiciones
				</label>
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-default">Registrarme</button>
			</div>
		</form>

		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="js/bootstrap.min.js"></script>
	</div>
</body>
</html>