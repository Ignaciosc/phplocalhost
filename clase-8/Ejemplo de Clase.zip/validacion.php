<?php
function validar(array $datos)
{
	$errores = [];

	if(trim($datos['nombre']) == '')
	{
		$errores['nombre'] = 'Debe ingresar Nombre';
	}

	if(trim($datos['apellido']) == '')
	{
		$errores['apellido'] = 'Debe ingresar Apellido';
	}

	if(!filter_var($datos['email'], FILTER_VALIDATE_EMAIL))
	{
		$errores['email'] = 'El email ingresado es inválido';
	}

	$passLen = 6;
	if(strlen($datos['pass']) < $passLen)
	{
		$errores['pass'] = 'El password debe tener ' . $passLen . ' o más caracteres';
	}
	elseif($datos['pass'] != $datos['pass_confirm'])
	{
		$errores['pass_confirm'] = 'El password debe ser igual a su confirmación';
	}

	if(strlen($datos['description']) < 20 || strlen($datos['description']) > 140)
	{
		$errores['description'] = 'LA descripción debe contener entre 20 y 140 caracteres';
	}

	if(!isset($datos['terminos']))
	{
		$errores['terminos'] = 'Debe aceptar los términos y condiciones';
	}

	if(!isset($datos['secciones']) || count($datos['secciones']) < 2)
	{
		$errores['secciones'] = 'Debe seleccionar al menos 2 secciones';
	}

	if(!checkdate($datos['mes'], $datos['dia'], $datos['anio']))
	{
		$errores['fecha'] = 'La fecha es invalida';
	}

	return $errores;
}

function validarLogin(array $datos)
{
	$errores = [];

	if(!filter_var($datos['email'], FILTER_VALIDATE_EMAIL))
	{
		$errores['email'] = 'El email ingresado es inválido';
	}

	return $errores;
}