<?php
require_once('funciones.php');
logout();