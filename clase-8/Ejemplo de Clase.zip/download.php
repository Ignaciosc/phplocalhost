<?php
require_once('funciones.php');
require_once('files.php');

download(AVATARS_DIRECTORY . $_GET['id']);