<?php
session_start();

require_once('files.php');

define('USERS_FILENAME', 'usuarios.json');
define('SESSION_USER_KEY', 'usuario');
define('COOKIE_USUARIO', 'mi_sitio_logged_user');

autologuear();

function getUsers()
{
	$content = json_decode(file_get_contents(USERS_FILENAME), true);
	return $content['usuarios'];
}

function saveUser($id, $datos)
{
	$users = getUsers();
	$users[] = [
		'id' => $id,
		'email' => $datos['email'],
		'password' => password_hash($datos['pass'], PASSWORD_BCRYPT, ['cost' => 10])
	];

	$content['usuarios'] = $users;
	file_put_contents(USERS_FILENAME, json_encode($content));
}

function saveAvatar($filename = null)
{
	uploadSingleFile('avatar', AVATARS_DIRECTORY, $filename);
}

function getById($id)
{
	$users = getUsers();
	foreach($users as $user)
	{
		if($user['id'] == $id)
		{
			return $user;
		}
	}

	return null;
}

function getByEmail($email)
{
	$users = getUsers();
	foreach($users as $user)
	{
		if($user['email'] == $email)
		{
			return $user;
		}
	}

	return null;
}

function registrarUsuario(array $datos)
{
	$errors = [];
	$id = 0;

	$users = getUsers();
	foreach($users as $user)
	{
		if($user['email'] == $datos['email'])
		{
			$errors['email'] = 'El email ingresado ya existe en nuestra base de datos.';
			break;
		}
		$id = $user['id'];
	}

	if(!$errors)
	{
		$id++;
		saveUser($id, $datos);
		saveAvatar($id);
		header('location: index.php');
		exit;
	}

	return $errors;
}

function loguearUsuario(array $datos)
{
	$errores = [];
	$user = getByEmail($datos['email']);

	if($user)
	{
		if(password_verify($datos['pass'], $user['password']))
		{
			unset($user['password']);
			$_SESSION[SESSION_USER_KEY] = $user;
			if(isset($datos['recordarme']))
			{
				setcookie(COOKIE_USUARIO, $user['id'], time() + 60*60*24*30);
			}

			//redirigirlo index.php
			header('location: index.php');
			exit;
		}
		else
		{
			$errores['pass'] = 'El password esta mal';
		}
	}
	else
	{
		$errores['email'] = 'El email ingresado no existe';
	}

	return $errores;
}

function autologuear()
{
	if(!isset($_SESSION[SESSION_USER_KEY]))
	{
		if(isset($_COOKIE[COOKIE_USUARIO]))
		{
			$idUsuario = $_COOKIE[COOKIE_USUARIO];
			$user = getById($idUsuario);
			unset($user['password']);
			$_SESSION[SESSION_USER_KEY] = $user;
		}
	}
}

function logout()
{
	session_destroy();
	setcookie(COOKIE_USUARIO, '', -1 * time());

	header('location: index.php');
	exit;
}