<?php

$filename = 'usuarios.json';

$f = fopen($filename, 'a+');

fwrite($f, 'Linea 1' . "\n");
fwrite($f, 'Linea 2' . PHP_EOL);

fclose($f);




file_put_contents($filename, 'Linea 3' . PHP_EOL, FILE_APPEND);