<?php
require_once('html.php');
require_once('funciones.php');
?>

<?php echo htmlOpen('Home'); ?>
	<?php echo pageHeader('Home'); ?>
		<div class="jumbotron">
			<?php if(!isset($_SESSION[SESSION_USER_KEY])) {?>
				<h1>YO SOY EL INDEX!</h1>
			<?php } else { ?>
				<h1><?php echo $_SESSION[SESSION_USER_KEY]['email'] ?></h1>
				<p><a href="download.php?id=<?php echo $_SESSION[SESSION_USER_KEY]['id']?>">Bajar Avatar</a></p>
			<?php } ?>
			<?php if(!isset($_SESSION[SESSION_USER_KEY])) {?>
				<p><a href="login.php">LOGIN</a></p>
			<?php } else { ?>
				<p><a href="logout.php">LOGOUT</a></p>
			<?php } ?>
			<p><a href="registracion.php">REGISTRACIÓN</a></p>
		</div>
<?php echo pageFooter(); ?>
<?php echo htmlClose(); ?>