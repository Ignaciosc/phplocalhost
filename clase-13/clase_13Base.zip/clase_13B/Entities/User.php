<?php

class User {
    private $id;
    private $firstName;
    private $lastName;
    private $email;
    private $username;
    private $password;
    private $birthDate;
    private $bio;

    /* @var Section[] */
    private $sections;

    public function __construct($firstName, $lastName, $email, $username, $password) {
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->email = $email;
        $this->username = $username;
        $this->password = $password;

        $this->sections = [];
    }
}

 ?>
