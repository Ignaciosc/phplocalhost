<?php

interface SectionRepository {
    public function listAll();
}

 ?>
