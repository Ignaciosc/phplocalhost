<?php
require_once('requires.php');

logout();