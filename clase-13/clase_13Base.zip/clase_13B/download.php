<?php
require_once('requires.php');

download(AVATARS_DIRECTORY . $_GET['id']);