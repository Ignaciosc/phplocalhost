<?php
require_once('requires.php');
?>

<?php echo htmlOpen('Felicitaciones'); ?>
	<?php echo pageHeader('Felicitaciones'); ?>
		<div class="jumbotron">
			<h1>Felicitiaciones</h1>
			<p>Te registraste exitósamente</p>
			<p><a class="btn btn-primary btn-lg" href="index.php" role="button">Volver</a></p>
		</div>
<?php echo pageFooter(); ?>
<?php echo htmlClose(); ?>