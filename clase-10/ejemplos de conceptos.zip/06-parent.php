<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>

<body>
<?php
$object = new Son;
$object->test();
$object->test2();

class Dad
{
function test()
{
echo "[Class Dad] I am your Father<br>";
}
}

class Son extends Dad
{
function test()
{
echo "[Class Son] I am Luke<br>";
}
function test2()
{
parent::test();
}
}

/*Este código crea una clase llamada Dad y luego una subclase llamada Son que hereda sus propiedades y métodos, y luego sobreescribe el método test. Por consiguiente, cuando la línea 2 llama al método test, el nuevo método es ejecutado. La única forma de ejecutar el método sobreescrito test en la clase Dad es usar el operador parent, como se muestra en la función test2 de la clase Son. El código devuelve lo siguiente:

[Class Son] I am Luke
[Class Dad] I am your Father

Si querés asegurarte que tu código llama a un método de la clase actual, podés usar la keyword self , de esta forma:
self::method();*/
?>
</body>
</html>