declare(strict_types=1);

function getTotal(float $a, float $b) {
      return $a + $b;
 }

getTotal(2, "1 week");
// Fatal error: Uncaught TypeError: Argument 2 passed to getTotal() must be of the type float, string given

getTotal(2.8,  "3.2");
// Fatal error: Uncaught TypeError: Argument 2 passed to getTotal() must be of the type float, string given

getTotal(2.5, 1);
// int(1) se cambia a float(1.0)
//returns float(3.5)

//La excepción al modo estricto se muestra en la tercer llamada. Si pasás un int como un argumento, el cuál está buscando un float, PHP hará lo que se llama “widening”, agregando .0 al final y la función devuelve 3.5.
