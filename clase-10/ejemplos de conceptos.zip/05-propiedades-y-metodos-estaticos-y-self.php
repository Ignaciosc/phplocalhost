<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>
<?php
//Definimos una clase llamada Test con una propiedad estática y un método público.

$temp = new Test();
echo "Test A: " . Test::$static_property . "<br>";
echo "Test B: " . $temp->get_sp() . "<br>";
echo "Test C: " . $temp->static_property . "<br>";

class Test
{
static $static_property = "Soy Estatico";
function get_sp()
{
return self::$static_property;
}
}

/*Al ejecutar este código, devuelve lo siguiente:
Test A: I'm static
Test B: I'm static
Notice: Undefined property: Test::$static_property
Test C:

Este ejemplo muestra que la propiedad $static_property puede ser directamente referenciada desde la clase misma via el doble operador dos puntos en Test A. También, Test B puede obtener su valor llamando al método get_sp del objeto $temp, creado desde la clase Test. Pero Test C falla, porque la propiedad estática $static_property no fue accesible para el objeto $temp.
Hay que notar como el método get_sp accede $static_property usando la keyword self. Esta es la forma en la cuál una propiedad estática o constante puede ser directamente accedida desde dentro de una clase.*/
?>

<body>
</body>
</html>
