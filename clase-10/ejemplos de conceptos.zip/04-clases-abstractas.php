<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>

<body>
<?php
/*Las clases abstractas son especiales porque no pueden ser instanciadas. En cambio, típicamente heredás un set de funcionalidades base en una nueva clase. Por esta razón, son comunmente usadas como las clases base en una gran herencia de clases.

Un método también puede ser marcado como abstracto. Tan pronto como marques una función clase como abstracta, tendrás que definir la clase como abstracta también (sólo las clases abstractas pueden contener funciones abstractas). Otra consecuencia es que no tendrás (no podrás) escribir código para la función, es sólo una declaración. Veamos un ejemplo:

*/

abstract class Animal
{
    public $name;
    public $age;

    public function Describe()
    {
        return $this->name . ", " . $this->age . " años de edad";
    }

    abstract public function Greet();
}

/*La palabra abstract se usa para marcar a la clase misma y a la última función como abstracta. Ahora vamos a crear una clase que pueda hererar de nuestra clase Animal:*/

class Dog extends Animal
{
    public function Greet()
    {
        return "Woof!";
    }

    public function Describe()
    {
        return parent::Describe() . ", y soy un perro!";
    }
}

/*Implementamos ambas funciones para la clase Animal. La función Greet() estamos forzados a implementarla, ya que está marcada como abstracta (devuelve una palabra/sonido común al animal que estamos creando). No estamos forzados a implementar la función Describe() (está implementada en la clase Animal), pero queremos extender la funcionalidad de ella. Ahora, podemos re-usar el código implementado en la clase Animal, y luego agregar a ella. En este caso, usamos la palabra parent para referirnos a la clase Animal, y luego llamamos a la función Describe() en ella. Luego agregamos texto extra al resultado, para clarificar con qué tipo de animal estamos tratando. Ahora, tratemos de usar esta nueva clase:*/

$animal = new Dog();
$animal->name = "Bob";
$animal->age = 7;
echo $animal->Describe();
echo $animal->Greet();

/*Instanciamos la clase Dog, seteamos las dos propiedades y luego llamamos los dos métodos definidos en él. Si probamos el código, veremos que el método Describe() es ahora una combinación de la Animal y de la versión Dog.*/
?>
</body>
</html>
