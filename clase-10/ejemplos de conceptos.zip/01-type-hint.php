<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>
<?php
/*Type Hints Escalables

Con PHP 7 ahora tenemos tipos de datos escalables. Específicamente: int, float, string y bool.

Por default, las declaraciones de tipo escalables son non-strict, lo que significa que se intentará cambiar el tipo original para que coincida con el tipo especificado en la declaración. En otras palabras, si pasás un string que comienza con un número a una función que requiere un float, tomará el número del comienzo y removerá todo lo demás. Pasar un float a una función que require un int se transformará en int(1).

Strict Example*/

function getTotal(float $a, float $b) {
    return $a + $b;
}

getTotal(2, "1 week");

// int(2) se cambia a (2.0) y el string “1 week” se cambia a float(1.0) pero recibirás un mensaje “Notice: A non well formed numeric value encountered”
//devuelve float(3)

getTotal(2.8, "3.2");
// el string "3.2" se cambia a float(3.2) sin mensajes
//devuelve float(6)

getTotal(2.5, 1);
// int(1) se cambia a float(1.0)
//devuelve float(3.5)

/*La función getTotal recibe 2 floats y los suma en el return.

Sin los strict types en on, PHP intenta moldear, o cambiar estos argumentos para coincidir con el tipo especificado en la función.

Ejemplo estricto

Adicionalmente, PHP 7 nos dá la oportunidad de habilitar el modo estricto en cada uno de los archivos. Hacemos esto declarando (strict_types=1); al comienzo de cada archivo. Esto DEBE ser la primera línea, incluso antes de los  namespaces. Declarar un tipo strict asegurará que cualquier llamado a la función hecho en ese archivo se apegue estrictamente a los tipos especificados.

Strict se determina por el archivo donde se hace la llamada a la función, no por el archivo donde se define a la función.*/


?>
<body>
</body>
</html>
