<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>

<body>
<?php
$object = new Subscriber;
$object->name = "Fred";
$object->password = "pword";
$object->phone = "012 345 6789";
$object->email = "fred@bloggs.com";
$object->display();

class User
{
public $name, $password;
function save_user()
{
echo "Codigo de guardar usuario.";
}
}

//La clase original User tiene dos propiedades, $name y $password, y un método para grabar el usuario actual en la base de datos.

class Subscriber extends User
{
public $phone, $email;
function display()
{
echo "Nombre: " . $this->name . "<br>";
echo "Pass: " . $this->password . "<br>";
echo "Telefono: " . $this->phone . "<br>";
echo "Email: " . $this->email;
}
}

//Subscriber extiende la clase User agregando dos propiedades adicionales, $phone e $email, e incluye un método para mostrar las propiedades del objeto actual usando la variable $this, la cual se refiere a los valores actuales del objeto al cual estamos accediendo. El output de este código es:

//Name: Fred
//Pass: pword
//Phone: 012 345 6789
//Email: fred@bloggs.com

?>
</body>
</html>
