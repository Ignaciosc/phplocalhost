<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>

<body>
<?php

//Cada clase interfaz es usualmente una colección de métodos que definen el comportamiento como en el siguiente ejemplo donde la clase records implementa la interfaz sort con los métodos ascending(), descending(), y shuffle().

interface sort {
function ascending();
function decendding();
function shuffle();
}

class records implements sort {
private $data = array();
function add($title) {
$this->data[] = $title;
}
function ascending() {
sort($this->data);
}
function decendding () {
rsort($this->data);
}
function shuffle() {
shuffle($this->data);
}
function get() {
return $this->data;
}
}

$beatles = new records();
$beatles->add("Yellow Submarine");
$beatles->add("Sgt. Pepper's Lonely Hearts Club Band");
$beatles->add("Help");
$beatles->add("Abbey Road");
echo "Ascending\n";
$beatles->ascending();
print_r($beatles->get());
echo "Decending\n";
$beatles->decendding();
print_r($beatles->get());
echo "Random\n";
$beatles->shuffle();
print_r($beatles->get());

/*En el ejemplo la variable $beatles es una instancia de la clase records y el título de cuatro álbumes famosos de  The Beatles es agregado al objeto. Luego el objeto es usado para ordenar e imprimir los datos en forma ascendente, descendente y en orden aleatorio. Nos devolverá algo como esto:

Ascending
Array
(
[0] => Abbey Road
[1] => Help
[2] => Sgt. Pepper's Lonely Hearts Club Band
[3] => Yellow Submarine
)
Decending
Array
(
[0] => Yellow Submarine
[1] => Sgt. Pepper's Lonely Hearts Club Band
[2] => Help
[3] => Abbey Road
)
Random
Array
(
[0] => Yellow Submarine
[1] => Help
[2] => Sgt. Pepper's Lonely Hearts Club Band
[3] => Abbey Road
)
*/
?>
</body>
</html>