<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>

<?php
// definimos una clase
class WidgetFactory
{
  var $oink = 'moo';
}

// creamos un nuevo objeto
$WF = new WidgetFactory();

//si el nuevo objeto $WF es una instancia de la clase WidgetFactory imprime el texto

if (is_a($WF instanceof WidgetFactory)) {
  echo "Si, \$WF sigue siendo un WidgetFactory\n";
}
?>

<body>
</body>
</html>
