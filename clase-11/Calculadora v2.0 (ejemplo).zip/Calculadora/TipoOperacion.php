<?php
class TipoOperacion
{
	const SUMA = 'suma';
	const RESTA = 'resta';
	const DIVISION = 'division';
	const MULTIPLICACION = 'multiplicacion';

	private $tipo;

	private function __construct($tipo)
	{
		$this->tipo = $tipo;
	}

	public static function suma()
	{
		return new TipoOperacion(self::SUMA);
	}

	public static function resta()
	{
		return new TipoOperacion(self::RESTA);
	}

	public static function division()
	{
		return new TipoOperacion(self::DIVISION);
	}

	public static function multiplicacion()
	{
		return new TipoOperacion(self::MULTIPLICACION);
	}

	public function is($tipo = null)
	{
		if($tipo)
		{
			return $this->tipo == $tipo;
		}

		return $this->tipo;
	}
}
