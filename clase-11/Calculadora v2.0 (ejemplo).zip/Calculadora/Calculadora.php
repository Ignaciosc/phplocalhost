<?php
require_once('OperationFactory.php');
require_once('TipoOperacion.php');

class Calculadora
{
	private $operationFactory;
	private $operacion;
	private $num1;
	private $num2;

	public function __construct(OperationFactory $operationFactory, TipoOperacion $tipoOperacion, $num1, $num2)
	{
		$this->operationFactory = $operationFactory;
		$this->makeOperacion($tipoOperacion, $num1, $num2);
	}

	private function makeOperacion($operacion, $num1, $num2)
	{
		$this->operacion = $this->operationFactory->make($operacion, $num1, $num2);
	}

	public function obtenerResultado()
	{
		return $this->operacion->operar();
	}
}
