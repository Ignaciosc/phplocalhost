<?php
interface Operacion
{
	public function operar();
}