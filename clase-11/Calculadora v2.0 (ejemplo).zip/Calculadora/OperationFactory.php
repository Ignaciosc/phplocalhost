<?php
require_once('Suma.php');
require_once('Resta.php');
require_once('Division.php');
require_once('Multiplicacion.php');
require_once('TipoOperacion.php');

class OperationFactory
{
	public function make(TipoOperacion $tipoOperacion, $num1, $num2)
	{
		switch($tipoOperacion->is())
		{
			case TipoOperacion::SUMA:
				return new Suma($num1, $num2);

			case TipoOperacion::RESTA:
				return new Resta($num1, $num2);

			case TipoOperacion::DIVISION:
				return new Division($num1, $num2);

			case TipoOperacion::MULTIPLICACION:
				return new Multiplicacion($num1, $num2);
		}
	}
}
