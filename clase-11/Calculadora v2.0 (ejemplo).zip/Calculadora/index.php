<?php
require_once('TipoOperacion.php');
require_once('OperationFactory.php');
require_once('Calculadora.php');

$operationFactory = new OperationFactory();

//SUMA
$num1 = 1;
$num2 = 2;
$calculadora = new Calculadora($operationFactory, TipoOperacion::suma(), $num1, $num2);
echo "El resutado de la suma entre $num1 y $num2 es " . $calculadora->obtenerResultado() . "<br/><br/>";

//RESTA
$num1 = 10;
$num2 = 5;
$calculadora = new Calculadora($operationFactory, TipoOperacion::resta(), $num1, $num2);
echo "El resutado de la resta entre $num1 y $num2 es " . $calculadora->obtenerResultado() . "<br/><br/>";

//DIVISION
$num1 = 500;
$num2 = 20;
$calculadora = new Calculadora($operationFactory, TipoOperacion::division(), $num1, $num2);
echo "El resutado de la division entre $num1 y $num2 es " . $calculadora->obtenerResultado() . "<br/><br/>";

//MULTIPLICACION
$num1 = 100;
$num2 = 7;
$calculadora = new Calculadora($operationFactory, TipoOperacion::multiplicacion(), $num1, $num2);
echo "El resutado de la multiplicacion entre $num1 y $num2 es " . $calculadora->obtenerResultado() . "<br/><br/>";
