<?php
require_once('Operacion.php');

class Division implements Operacion
{
	private $num1;
	private $num2;
	
	public function __construct($num1, $num2)
	{
		$this->num1 = $num1;
		$this->setDivisor($num2);
	}
	
	private function setDivisor($divisor)
	{
		if($divisor == 0)
		{
			throw new Exception('No se puede dividir por cero');
		}
		
		$this->num2 = $divisor;
	}

	public function operar()
	{
		return $this->num1 / $this->num2;
	}
}