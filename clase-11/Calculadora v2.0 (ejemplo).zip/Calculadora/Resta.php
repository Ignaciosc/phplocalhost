<?php
require_once('Operacion.php');

class Resta implements Operacion
{
	private $num1;
	private $num2;
	
	public function __construct($num1, $num2)
	{
		$this->num1 = $num1;
		$this->num2 = $num2;
	}

	public function operar()
	{
		return $this->num1 - $this->num2;
	}
}