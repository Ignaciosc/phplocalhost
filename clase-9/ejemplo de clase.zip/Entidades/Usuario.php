<?php

class Usuario
{
	const MI_CONSTANTE = 1;

	private $id;
	private $miVarInicializada = 2;
	private $miVarInicializada2;

	private $cuit;

	public function __construct($id)
	{
		$this->setId($id);

		$this->miVarInicializada2 = self::MI_CONSTANTE;
	}

	public function setId($id)
	{
		if(!$this->validateEntero($id))
		{
			$up = new Exception('El id debe ser numérico');
			throw $up;
		}

		$this->id = $id;
	}

	public function getId()
	{
		return $this->id;
	}

	private function validateEntero($param)
	{
		return is_int($param);
	}
}