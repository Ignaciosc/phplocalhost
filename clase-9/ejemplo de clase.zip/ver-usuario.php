<?php

require_once('Entidades\Usuario.php');

/*$user = new Usuario;
var_dump($user);

$user = new Usuario();
var_dump($user);

$user = new Usuario(4);
var_dump($user);

$id = 5;
$user = new Usuario($id);
var_dump($user);
*/
/*
$id = 5;
$user = new Usuario($id);
echo $user->id;
$user->id = 8;
echo $user->id;
*/
/*
try
{
	$id = 5;
	$user = new Usuario($id);
	$user->setId('snsrn');

	echo $user->getId();
}
catch(Exception $e)
{
	echo $e->getMessage();
}
*/

echo Usuario::MI_CONSTANTE;